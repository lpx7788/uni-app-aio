const ApiUrl = 'http://192.168.0.230:8080';
const WebSocketUrl = 'ws://192.168.0.230:8080'
const H5Url = 'http://192.168.0.230:7001'

// const ApiUrl = 'https://aio.manytrader.net';
// const WebSocketUrl = 'wss://aio.manytrader.net'

export default {
  ApiUrl,
  WebSocketUrl,
  H5Url
}
      